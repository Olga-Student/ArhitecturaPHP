<?php


namespace ORM\Repository;

use ORM\Contract\DbQueryBuilderInterface;

class MySQLDbQueryBuilderRepository extends BaseMySQLRepository implements DbQueryBuilderInterface
{

    public function getOne()
    {
        // TODO: Implement getOne() method.
    }

    public function getAll()
    {
        // TODO: Implement getAll() method.
    }
}