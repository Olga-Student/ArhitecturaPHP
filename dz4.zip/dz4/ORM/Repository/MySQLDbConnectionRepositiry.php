<?php


namespace ORM\Repository;

use ORM\Contract\DbConnectionInterface;

class MySQLDbConnectionRepositiry extends BaseMySQLRepository implements DbConnectionInterface
{

    public function addConnection()
    {
        // TODO: Implement addConnection() method.
    }

    public function delConnection()
    {
        // TODO: Implement delConnection() method.
    }
}