<?php


namespace ORM\Contract;


interface DbConnectionInterface
{
     public function addConnection();

     public function delConnection();
}