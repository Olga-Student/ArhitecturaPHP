<?php


namespace ORM\Repository;

use ORM\Contract\DbQueryBuilderInterface;

class OracleDbQueryBuilderRepository extends BaseOracleRepository implements DbQueryBuilderInterface
{

    public function getOne()
    {
        // TODO: Implement getOne() method.
    }

    public function getAll()
    {
        // TODO: Implement getAll() method.
    }
}