<?php


namespace ORM\Repository;

use ORM\Contract\DbRecordInterface;

class OracleDbRecordRepository extends BaseOracleRepository implements DbRecordInterface
{

    public function add()
    {
        // TODO: Implement add() method.
    }

    public function delete()
    {
        // TODO: Implement delete() method.
    }

    public function update()
    {
        // TODO: Implement update() method.
    }
}