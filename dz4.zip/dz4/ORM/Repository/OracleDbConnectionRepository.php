<?php


namespace ORM\Repository;

use ORM\Contract\DbConnectionInterface;

class OracleDbConnectionRepository extends BaseOracleRepository implements DbConnectionInterface
{

    public function addConnection()
    {
        // TODO: Implement addConnection() method.
    }

    public function delConnection()
    {
        // TODO: Implement delConnection() method.
    }
}