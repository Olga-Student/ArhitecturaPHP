<?php

namespace ORM\Db;


class MySQL
{

}