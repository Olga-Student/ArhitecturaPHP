<?php


namespace ORM\Db;


class Oracle
{

}